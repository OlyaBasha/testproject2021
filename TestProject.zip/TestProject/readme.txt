Below settings were set for this project:
Compiler - Javac
Project bytecode version - 11
Target bytecode version - 11
Language level - 11
SDK - 13