Below settings were set for this project:
Compiler - Javac
Project bytecode version - 11
Target bytecode version - 11
Language level - 11
SDK - 13

After downloading and opening a project, click on the pom.xml file and choose 'Add as Maven Project'