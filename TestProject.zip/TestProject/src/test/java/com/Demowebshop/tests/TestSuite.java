package com.Demowebshop.tests;

import com.Demowebshop.webpages.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.concurrent.TimeUnit;

public class TestSuite {
    WebDriver driver;

    //Setting up driver
    @BeforeClass
    public static void setupClass() {
        WebDriverManager.chromedriver().setup();
    }

    @Before
    public void setupTest() {
        driver = new ChromeDriver();
        //Maximize the window
        driver.manage().window().maximize();
        //Optional delay = 10sec
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        //Open site URL
        driver.get(ConfProperties.getProperty("mainPage"));
    }

    @Test
    // Registration Test
    public void registration() {

        //Create Object of Main Page
        MainPage main = new MainPage(driver);
        // Create Object of Utils Page
        Utils utils = new Utils(driver);

        //Open a registration form
        main.openRegistrationForm();

        //Fill out the form with valid data
        main.selectGender();
        main.enterFirstName(ConfProperties.getProperty("firstName"));
        main.enterLastName(ConfProperties.getProperty("lastName"));
        main.enterEmail(utils.genEmail());
        main.enterPwd(ConfProperties.getProperty("password"));
        main.confirmPwd(ConfProperties.getProperty("password"));
        //Submit
        main.clickRegisterBtn();
        //Save generated user email to use it in future tests
        utils.setEmail(main.getUserEmail());
        //Check if the user registered
        Assert.assertEquals(ConfProperties.getProperty("registerSuccessMessage"), main.getResultMessage());
        // logging out
        main.logout();
    }


    @Test
    // Log in and add an Item to the Shopping Cart test
    public void addItemToTheShoppingCart() {
        //Create Object of Main Page
        MainPage main = new MainPage(driver);
        // Create Object of Utils Page
        Utils utils = new Utils(driver);
        // Create Object of Books Category Page
        BooksCategory booksCategory = new BooksCategory(driver);

        //Open the Login page
        driver.get(ConfProperties.getProperty("loginPage"));
        //Fill out the form using previously saved email
        main.checkEmail(ConfProperties.getProperty("usrEmail"));
        main.enterPassword(ConfProperties.getProperty("password"));
        main.checkRememberMeCheckbx();
        main.clickLogin();
        //Open Books category and add a book to a shopping cart
        booksCategory.openBooksCatLeftBar();
        booksCategory.chooseBook();
        booksCategory.addToCart();
        //Verify if the book was added to a shopping cart
        Assert.assertEquals(ConfProperties.getProperty("addedToCartMessage"), booksCategory.getSuccessMessageAddedToCart());

        // logging out
        main.logout();
    }


    @Test
    //Make the purchase and save order number
    public void buyItem() {
        //Create Object of Main Page
        MainPage main = new MainPage(driver);
        // Create Object of Utils Page
        Utils utils = new Utils(driver);
        //Create Object of Shopping Cart Page
        ShoppingCartPage shoppingCart = new ShoppingCartPage(driver);

        //Open the Login page
        driver.get(ConfProperties.getProperty("loginPage"));
        //Fill out the form using previously saved email
        main.checkEmail(ConfProperties.getProperty("usrEmail"));
        main.enterPassword(ConfProperties.getProperty("password"));
        main.checkRememberMeCheckbx();
        main.clickLogin();
        //Go to the shopping cart
        main.openShoppingCart();
        // Fill out the forms
        shoppingCart.checkShoppingCart();
        shoppingCart.billingAddress(ConfProperties.getProperty("city"), ConfProperties.getProperty("address"),ConfProperties.getProperty("zip"),ConfProperties.getProperty("phoneNumber"));
        shoppingCart.shippingAddress();
        shoppingCart.shippingMethod();
        shoppingCart.paymentMethod();
        shoppingCart.paymentInformation();
        shoppingCart.confirmOrder();
        //Verify if the purchase was made
        Assert.assertEquals(ConfProperties.getProperty("makePurchaseSuccessMessage"), shoppingCart.getSuccessMessageOrderConfirmation());
        //Save order number
        utils.setOrderDetailNumber(shoppingCart.saveOrderNumber());
    }

    @After
    //Close the browser
        public void tearDown() {
            if (driver != null) {
                driver.quit();
            }
        }


}