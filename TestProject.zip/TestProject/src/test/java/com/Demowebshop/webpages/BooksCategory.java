package com.Demowebshop.webpages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BooksCategory {
    WebDriver driver;

    //Constructor
    public BooksCategory (WebDriver driver) {
        this.driver = driver;

        //Initialise Elements
        PageFactory.initElements(driver, this);
    }

    // Defining elements' locators on the Category - Book page
    @FindBy(xpath = "//A[@href='/books']")
    private WebElement booksCategoryLeftBar;

    @FindBy(xpath = "//div[@class='header-menu']//ul[@class='top-menu']//A[@href='/books']")
    private WebElement booksCategoryTopBar;

    @FindBy(xpath = "//div[@class='product-item']//a[@href='/computing-and-internet'][text()='Computing and Internet']")
    private WebElement computingBook;

    @FindBy(xpath = "//input[@value='Add to cart']")
    private WebElement addToCartBtn;

    @FindBy(id = "bar-notification")
    private WebElement notifBar;

    @FindBy(className = "content")
    private WebElement successMess;

    // Test methods
    public void openBooksCatLeftBar(){
        booksCategoryLeftBar.click();
    }

    public void openBooksCatTopBar() {booksCategoryTopBar.click(); }

    public void chooseBook(){ computingBook.click(); }

    public void addToCart(){ addToCartBtn.click(); }

    //Getting a success message after adding an item to the cart
    public String getSuccessMessageAddedToCart(){
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("bar-notification")));
        String addedToCartSuccessMessage = notifBar.getText().trim();
        return addedToCartSuccessMessage;
    }


}
