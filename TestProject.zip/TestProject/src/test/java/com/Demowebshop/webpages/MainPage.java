package com.Demowebshop.webpages;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Optional;

public class MainPage {
    private WebDriver driver;

    Utils utils = new Utils(driver);

    // Defining elements' locators on the Main page
    @FindBy(id = "gender-female")
    private WebElement femaleRdbtn;

    @FindBy(id = "FirstName")
    private WebElement firstNameFld;

    @FindBy(id = "LastName")
    private WebElement lastNameFld;

    @FindBy(id = "Email")
    private WebElement emailFld;

    @FindBy(id = "Password")
    private WebElement passwordFld;

    @FindBy(id = "ConfirmPassword")
    private WebElement confirmPasswordFld;

    @FindBy(id = "register-button")
    private WebElement registerBtn;

    @FindBy(className = "result")
    private WebElement resultMessage;

    @FindBy(xpath = "//A[@href='/customer/info']")
    private WebElement userEmail;

    @FindBy(xpath = "//A[@class='ico-register'][text()='Register']")
    private WebElement registerSection;

    @FindBy(id = "RememberMe")
    private WebElement remembMeChckbx;

    @FindBy(xpath = "//INPUT[@class='button-1 login-button']")
    private WebElement loginBtn;

    @FindBy(xpath = "//A[@href='/logout']")
    private WebElement logoutBtn;

    @FindBy(xpath = "//SPAN[@class='cart-label'][text()='Shopping cart']")
    private WebElement shoppingCart;

    //Constructor
    public MainPage(WebDriver driver) {
        this.driver = driver;

        //Initialise Elements
        PageFactory.initElements(driver, this);
    }

    // Actions should be taken/ Test methods
    public void openRegistrationForm(){
        registerSection.click();
    }

    public void logout(){
        logoutBtn.click();
    }

    public void enterEmail(String email){
        emailFld.sendKeys(email);
    }

    public void enterPassword(String pwd){
        passwordFld.sendKeys(pwd);
    }

    public void checkRememberMeCheckbx(){ remembMeChckbx.click(); }

    public void clickLogin(){
        loginBtn.click();
    }

    public void selectGender(){
        femaleRdbtn.click();
    }

    public void enterFirstName(String firstName){
        firstNameFld.sendKeys(firstName);
    }

    public void enterLastName(String lastName){
        lastNameFld.sendKeys(lastName);
    }

    public void enterPwd(String password){
        passwordFld.sendKeys(password);
    }

    public void confirmPwd(String password){
        confirmPasswordFld.sendKeys(password);
    }

    public void clickRegisterBtn(){
        registerBtn.click();
    }

    //Check if the setter returns an email, if not - use default email from properties file
    public String checkEmail(String defaultValue) {
        String newEmail = Optional.ofNullable(utils.getEmail()).orElse(defaultValue);
        emailFld.sendKeys(newEmail);
        return newEmail;
    }

    //Getting a message after registration
    public String getResultMessage(){
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("result")));
        String resMessage = resultMessage.getText();
        return resMessage;
    }

    //Getting user email
    public String getUserEmail(){
        String usersEmail = userEmail.getText();
        return usersEmail;
    }

    public void openShoppingCart(){
        shoppingCart.click();
    }

}
