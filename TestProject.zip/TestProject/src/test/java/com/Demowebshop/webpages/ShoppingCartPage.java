package com.Demowebshop.webpages;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ShoppingCartPage {
    WebDriver driver;

    //Constructor
    public ShoppingCartPage (WebDriver driver) {
        this.driver = driver;

        //Initialise Elements
        PageFactory.initElements(driver, this);
    }

    //Finding elements locators on the Shopping Cart page
    @FindBy(id = "termsofservice")
    private WebElement termsCheckbx;

    @FindBy(id = "checkout")
    private WebElement checkoutBtn;

    @FindBy(xpath = "(//INPUT[@type='button'][@title='Continue'])")
    private WebElement continueBtn;

    @FindBy(xpath = "//div[@class='buttons']//INPUT[@onclick='Billing.save()']")
    private WebElement continueBillingAddr;

    @FindBy(xpath = "//div[@class='buttons']//INPUT[@onclick='Shipping.save()']")
    private WebElement continueShippingAddr;

    @FindBy(xpath = "//div[@class='buttons']//INPUT[@onclick='ShippingMethod.save()']")
    private WebElement continueShippingMethod;

    @FindBy(xpath = "//div[@class='buttons']//INPUT[@onclick='PaymentMethod.save()']")
    private WebElement continuePaymentMethod;

    @FindBy(xpath = "//div[@class='buttons']//INPUT[@onclick='PaymentInfo.save()']")
    private WebElement continuePaymentInfo;

    @FindBy(xpath = "//DIV[@class='order-summary-content'][contains(text(), 'Your Shopping Cart is empty!')]")
    private WebElement isCartEmpty;

    @FindBy(id = "BillingNewAddress_CountryId")
    private WebElement countryDpdwn;

    @FindBy(id = "BillingNewAddress_City")
    private WebElement cityFld;

    @FindBy(id = "BillingNewAddress_Address1")
    private WebElement address1Fld;

    @FindBy(id = "BillingNewAddress_ZipPostalCode")
    private WebElement zipFld;

    @FindBy(xpath = "//INPUT[@id='BillingNewAddress_PhoneNumber']")
    private WebElement phoneNumFld;

    @FindBy(xpath = "//INPUT[@value='Next Day Air___Shipping.FixedRate']")
    private WebElement nextDayShipping;

    @FindBy(xpath = "//INPUT[@value='Confirm']")
    private WebElement confirmBtn;

    @FindBy(xpath = "//DIV[@class='title']//STRONG[text()='Your order has been successfully processed!']")
    private WebElement purchaseSuccessMessage;

    @FindBy(xpath = "//ul[@class='details']//li[1]")
    private WebElement orderDetails;

    @FindBy(xpath = "//div[@data-productid='13']//input[@value='Add to cart']")
    private WebElement addToCartBtn;


    //Test methods

    //This method checks if the Shopping cart is empty; if yes - adds an Item;
    public void checkShoppingCart() {
        BooksCategory booksCategory = new BooksCategory(driver);
        MainPage main = new MainPage(driver);
        try {
            if (isCartEmpty.isDisplayed()) {
                booksCategory.openBooksCatTopBar();
                addToCartBtn.click();
                WebDriverWait wait = new WebDriverWait(driver, 10);
                wait.until(ExpectedConditions.elementToBeClickable(addToCartBtn)).click();
//                booksCategory.addToCart();
                Assert.assertEquals(ConfProperties.getProperty("addedToCartMessage"), booksCategory.getSuccessMessageAddedToCart());
                main.openShoppingCart();
            }
            if (isCartEmpty.isDisplayed()){
                driver.navigate().refresh();
            }
                // check if the book was added by checking the presence of 'Checkout' button
            if (checkoutBtn.isDisplayed()) {
                termsCheckbx.click();
                checkoutBtn.click();
            }
        } catch (Exception e) {
        if (checkoutBtn.isDisplayed()) {
                termsCheckbx.click();
                checkoutBtn.click();
            } else {
                System.out.println("Shopping Cart contains unpredictable result.");
            }
        }
    }

    //Filling out Billing Address form
    public void billingAddress(String city, String address, String zip, String phoneNumber) {
        if (cityFld.isDisplayed()) {
            new Select(countryDpdwn).selectByVisibleText("Canada");
            cityFld.sendKeys(city);
            address1Fld.sendKeys(address);
            zipFld.sendKeys(zip);
            phoneNumFld.sendKeys(phoneNumber);
            continueBillingAddr.click();
        } else {
            continueBillingAddr.click();
        }
    }

    //Filling out Shipping Address form
    public void shippingAddress(){
        continueShippingAddr.click();
    }

    //Filling out Shipping Method form
    public void shippingMethod(){
        nextDayShipping.click();
        continueShippingMethod.click();
    }

    //Filling out Payment Method form
    public void paymentMethod(){
        continuePaymentMethod.click();
    }

    //Filling out Payment Information form
    public void paymentInformation(){
        continuePaymentInfo.click();
    }

    //Order Confirmation
    public void confirmOrder(){
        confirmBtn.click();
    }

    //Getting success message after order confirmation
    public String getSuccessMessageOrderConfirmation(){
        String makePurchaseSuccessMessage = purchaseSuccessMessage.getText().trim();
        return makePurchaseSuccessMessage;
    }

    //Saving order number (for future); In a real test case it would be helpful
    public String saveOrderNumber(){
        String orderDetail = orderDetails.getText().trim();
        System.out.println(orderDetail);
        return orderDetail;
    }



}
