package com.Demowebshop.webpages;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class Utils {
    private WebDriver driver;

    //Constructor
    public Utils(WebDriver driver){
        this.driver = driver;

        //Initialise Elements
        PageFactory.initElements(driver, this);
    }

    // Email randomizer
    public String genEmail() {
        String randomText = "abcdefghijklmnopqrstuvwxyz";
        int length = 4;
        String temp = RandomStringUtils.random(length, randomText);
        final String email = temp + "@email.com";
        return email;
    }

    //Getting and setting user email
    private static String email;
    public void setEmail(String newEmail){
        email = newEmail;
    }
    public String getEmail(){
        return email;
    }

    //Setting an order details number
    private static String orderDetailNumber;
    public void setOrderDetailNumber(String orderNum) {orderDetailNumber = orderNum; }


}
